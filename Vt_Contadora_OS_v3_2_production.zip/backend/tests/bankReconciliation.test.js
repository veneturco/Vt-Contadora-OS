const { test } = require('node:test');
const assert = require('node:assert/strict');
const {
  parseBankStatementCsv,
  calculateExchangeDifferenceNic21,
  breakdownPosSettlementBatch,
  runDeterministicBankReconciliation
} = require('../services/seniatEngine');

test('Conciliación Bancaria: Ingesta y Parsing de extracto bancario venezolano (CSV/TXT)', () => {
  const sampleBanescoCsv = `FECHA,REFERENCIA,DESCRIPCION,MONTO,SALDO
15/11/2026,0098412,"PAGO MOVIL C2P Banesco",91402.00,150000.00
15/11/2026,482910,"ABONO CIERRE LOTE POS TERMINAL",96700.00,246700.00
14/11/2026,001842,"COMISION MANTENIMIENTO MENSUAL",-450.00,246250.00
14/11/2026,771294,"DEBITO IGTF 3% OPERACION DIVISAS",-2742.00,243508.00`;

  const parsed = parseBankStatementCsv(sampleBanescoCsv, 'BANESCO', 'tenant_1');
  assert.equal(parsed.length, 4, 'Debe parsear exactamente 4 movimientos');

  assert.equal(parsed[0].movementType, 'PAGO_MOVIL');
  assert.equal(parsed[0].amountBs, 91402.00);
  assert.equal(parsed[0].referenceNumber, '0098412');

  assert.equal(parsed[1].movementType, 'CIERRE_LOTE_POS');
  assert.equal(parsed[1].amountBs, 96700.00);

  assert.equal(parsed[2].movementType, 'COMISION_BANCARIA');
  assert.equal(parsed[2].amountBs, -450.00);

  assert.equal(parsed[3].movementType, 'DEBITO_IGTF');
  assert.equal(parsed[3].amountBs, -2742.00);
});

test('Conciliación Bancaria: Desglose automático de Cierres de Lote POS (Comisión 1.8% + Retención 1.5%)', () => {
  const netDeposit = 96700.00;
  const breakdown = breakdownPosSettlementBatch(netDeposit, 1.8, 1.5);

  // Venta bruta = 96700 / (1 - 0.033) = 100000.00
  assert.equal(breakdown.grossSalesBs, 100000.00, 'Venta bruta debe calcularse en Bs. 100.000,00');
  assert.equal(breakdown.bankFeeBs, 1800.00, 'Comisión bancaria 1.8% debe ser Bs. 1.800,00');
  assert.equal(breakdown.seniatRetBs, 1500.00, 'Retención SENIAT 1.5% debe ser Bs. 1.500,00');
  assert.equal(breakdown.netDepositBs, 96700.00, 'Depósito neto debe coincidir exactamente con el banco');
});

test('Conciliación Bancaria: Cálculo de Diferencial Cambiario VEN-NIF NIC 21 (Ganancia vs Pérdida)', () => {
  // Factura emitida a $100 con BCV histórico de 880.00 = Bs. 88.000,00
  // Pago recibido en fecha posterior con BCV oficial de 914.02 = Bs. 91.402,00
  const gainResult = calculateExchangeDifferenceNic21({
    invoiceTotalOriginal: 100,
    invoiceCurrency: 'USD',
    invoiceBcvRate: 880.00,
    paymentBcvRate: 914.02,
    paidAmountBs: 91402.00
  });

  assert.equal(gainResult.gainOrLoss, 'GANANCIA', 'Debe clasificar como Ganancia Cambiaria');
  assert.equal(gainResult.diffBs, 3402.00, 'Diferencia a favor debe ser de Bs. 3.402,00');
  assert.ok(gainResult.diffPercent > 3.8, 'El porcentaje de incremento debe ser ~3.86%');

  // Caso Pérdida: Factura cobrada por debajo de la tasa histórica
  const lossResult = calculateExchangeDifferenceNic21({
    invoiceTotalOriginal: 100,
    invoiceCurrency: 'USD',
    invoiceBcvRate: 920.00,
    paymentBcvRate: 914.02,
    paidAmountBs: 91402.00
  });

  assert.equal(lossResult.gainOrLoss, 'PERDIDA', 'Debe clasificar como Pérdida Cambiaria');
  assert.equal(lossResult.diffBs, -598.00, 'Diferencia en contra debe ser de -Bs. 598,00');
});

test('Conciliación Bancaria: Matching determinista entre extracto bancario y facturas del sistema', () => {
  const bankMoves = [
    {
      id: 'mov_1',
      tenantId: 't1',
      bankName: 'BANESCO',
      date: '2026-11-15',
      referenceNumber: '0098412',
      description: 'PAGO MOVIL C2P REF 0098412',
      amountBs: 91402.00,
      movementType: 'PAGO_MOVIL',
      reconciliationStatus: 'PENDIENTE'
    },
    {
      id: 'mov_2',
      tenantId: 't1',
      bankName: 'BANESCO',
      date: '2026-11-15',
      referenceNumber: '482910',
      description: 'ABONO CIERRE LOTE POS TERMINAL',
      amountBs: 96700.00,
      movementType: 'CIERRE_LOTE_POS',
      reconciliationStatus: 'PENDIENTE'
    },
    {
      id: 'mov_3',
      tenantId: 't1',
      bankName: 'BANESCO',
      date: '2026-11-14',
      referenceNumber: '001842',
      description: 'COMISION MANTENIMIENTO MENSUAL',
      amountBs: -450.00,
      movementType: 'COMISION_BANCARIA',
      reconciliationStatus: 'PENDIENTE'
    }
  ];

  const invoices = [
    {
      id: 'inv_101',
      tenantId: 't1',
      invoiceNumber: '0098412',
      controlNumber: '00-0098412',
      currency: 'USD',
      totalOriginal: 100,
      bcvRateOnDate: 880.00
    }
  ];

  const result = runDeterministicBankReconciliation(bankMoves, invoices, 914.02);

  assert.equal(result.matchedCount, 2, 'Debe conciliar la factura y el lote POS');
  assert.equal(result.totalGainCambiariaBs, 3402.00, 'Debe acumular Bs. 3.402 de ganancia cambiaria');

  const move1 = result.reconciledMoves.find(m => m.id === 'mov_1');
  assert.equal(move1.reconciliationStatus, 'DIFERENCIAL_CAMBIARIO');
  assert.equal(move1.matchedInvoiceId, 'inv_101');
  assert.equal(move1.exchangeDiffBs, 3402.00);

  const move2 = result.reconciledMoves.find(m => m.id === 'mov_2');
  assert.equal(move2.reconciliationStatus, 'CONCILIADO');
  assert.ok(move2.posBreakdown, 'Lote POS debe incluir desglose');
  assert.equal(move2.posBreakdown.grossSalesBs, 100000.00);
});
