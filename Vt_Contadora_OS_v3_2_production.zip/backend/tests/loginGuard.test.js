const test = require('node:test');
const assert = require('node:assert/strict');
const {
  MAX_FAILED_ATTEMPTS,
  LOCKOUT_DURATION_MS,
  checkLockStatus,
  recordFailedAttempt,
  recordSuccessfulLogin,
  manualUnlock,
  listSecurityIncidents,
  resetStateForTests
} = require('../security/loginGuard');

test('LoginGuard: Detección y bloqueo progresivo contra ataques de fuerza bruta', () => {
  resetStateForTests();
  const testEmail = 'auditor.prueba@veneturco.com';
  const ip = '190.202.12.88';

  // 1. Estado inicial limpio
  const initial = checkLockStatus(testEmail);
  assert.equal(initial.isLocked, false);
  assert.equal(initial.attempts, 0);

  // 2. Intentos 1 al 4: no bloquean la cuenta
  for (let i = 1; i <= 4; i++) {
    const res = recordFailedAttempt(testEmail, ip);
    assert.equal(res.isLocked, false);
    assert.equal(res.attempts, i);
    assert.equal(res.remainingAttempts, MAX_FAILED_ATTEMPTS - i);
    if (i >= 3) {
      assert.equal(res.shouldTarpit, true); // Retardo activo a partir del 3er fallo
    }
  }

  // Verificar que al 4to intento sigue sin bloquearse
  const statusAfter4 = checkLockStatus(testEmail);
  assert.equal(statusAfter4.isLocked, false);

  // 3. 5to intento fallido: BLOQUEO AUTOMÁTICO INMEDIATO POR 30 MINUTOS
  const res5 = recordFailedAttempt(testEmail, ip);
  assert.equal(res5.isLocked, true);
  assert.equal(res5.attempts, 5);
  assert.equal(res5.remainingAttempts, 0);
  assert.ok(res5.lockedUntil !== null);
  assert.ok(res5.incident !== null);
  assert.equal(res5.incident.type, 'ACCOUNT_LOCKED_BRUTE_FORCE');
  assert.equal(res5.incident.hash.length, 64); // Hash SHA-256

  // 4. Consulta de estado mientras está bloqueada
  const statusLocked = checkLockStatus(testEmail);
  assert.equal(statusLocked.isLocked, true);
  assert.ok(statusLocked.remainingMinutes >= 29 && statusLocked.remainingMinutes <= 30);

  // 5. Verificar lista de incidentes para el Super-Administrador
  const incidents = listSecurityIncidents();
  assert.equal(incidents.activeLocks.length, 1);
  assert.equal(incidents.activeLocks[0].identifier, testEmail);
  assert.equal(incidents.activeLocks[0].attempts, 5);

  // 6. Desbloqueo manual por Super-Administrador
  const unlockRes = manualUnlock(testEmail, 'superadmin_1');
  assert.equal(unlockRes.success, true);
  assert.equal(unlockRes.unlockedBy, 'superadmin_1');
  assert.equal(unlockRes.auditHash.length, 64);

  // 7. Cuenta liberada y accesible nuevamente
  const statusAfterUnlock = checkLockStatus(testEmail);
  assert.equal(statusAfterUnlock.isLocked, false);
  assert.equal(statusAfterUnlock.attempts, 0);

  // 8. Flujo de login exitoso tras intentos parciales
  recordFailedAttempt(testEmail, ip);
  recordFailedAttempt(testEmail, ip);
  assert.equal(checkLockStatus(testEmail).attempts, 2);
  recordSuccessfulLogin(testEmail);
  assert.equal(checkLockStatus(testEmail).attempts, 0);
});
