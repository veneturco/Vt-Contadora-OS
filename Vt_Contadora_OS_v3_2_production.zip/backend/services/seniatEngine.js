function validateVenezuelanRIF(rif) {
  const clean = String(rif || '').trim().toUpperCase().replace(/[^JVEGP0-9]/g, '');
  if (!/^[JVEGP][0-9]{9}$/.test(clean)) return { valid: false, formatted: rif, reason: 'Formato RIF invalido' };

  const prefixWeights = { V: 1, E: 2, J: 3, P: 4, G: 5 };
  const multipliers = [3, 2, 7, 6, 5, 4, 3, 2];
  let sum = prefixWeights[clean[0]] * 4;

  for (let i = 0; i < 8; i++) {
    sum += parseInt(clean[i + 1], 10) * multipliers[i];
  }

  const remainder = sum % 11;
  const expectedDigit = remainder > 1 ? 11 - remainder : 0;
  const actualDigit = parseInt(clean[9], 10);

  return {
    valid: expectedDigit === actualDigit,
    formatted: `${clean[0]}-${clean.slice(1, 9)}-${clean[9]}`,
    expectedDigit,
    actualDigit
  };
}

function buildRetentionVoucherNumber(yearMonth, correlativeSeq) {
  // Providencia SNAT/2026/00093 Art. 18: 14 digitos AAAAMMSSSSSSSS
  const ym = String(yearMonth).replace(/[^0-9]/g, '').slice(0, 6);
  const seq = String(correlativeSeq).padStart(8, '0').slice(-8);
  return `${ym}${seq}`;
}

function generateSeniatIvaTxt16Columns(agentRif, periodYYYYMM, rows) {
  const cleanAgentRif = agentRif.replace(/-/g, '').toUpperCase();
  if (!rows || rows.length === 0) {
    return `${cleanAgentRif}\t${periodYYYYMM}\t0\tC\t0\t0\t1\t0\t0.00\t0.00\t0.00\t0\t0\t0.00\t0.00\t0`;
  }

  return rows.map((r, idx) => {
    const voucher14 = r.voucherNumber || buildRetentionVoucherNumber(periodYYYYMM, idx + 1);
    const cols = [
      cleanAgentRif,
      periodYYYYMM,
      r.emissionDate,
      r.operationType || 'C',
      r.docType || '01',
      r.supplierRif.replace(/-/g, '').toUpperCase(),
      r.invoiceNumber,
      r.controlNumber,
      Number(r.totalBs).toFixed(2),
      Number(r.taxableBaseBs).toFixed(2),
      Number(r.ivaWithheldBs).toFixed(2),
      r.affectedDocument || '0',
      voucher14,
      Number(r.exemptBs || 0).toFixed(2),
      Number(r.vatRate || 16).toFixed(2),
      r.expediente || '0'
    ];
    return cols.join('\t');
  }).join('\n');
}

function escapeXml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function generateIslrDecreto1808Xml(agentRif, periodYYYYMM, retentions) {
  const cleanAgent = escapeXml(String(agentRif || '').replace(/-/g, '').toUpperCase());
  const cleanPeriod = escapeXml(String(periodYYYYMM || '').replace(/[^0-9]/g, '').slice(0, 6));
  const itemsXml = retentions.map(r => `  <DetalleRetencion>
    <RifRetenido>${escapeXml(String(r.supplierRif || '').replace(/-/g, '').toUpperCase())}</RifRetenido>
    <NumeroFactura>${escapeXml(r.invoiceNumber)}</NumeroFactura>
    <NumeroControl>${escapeXml(r.controlNumber)}</NumeroControl>
    <FechaOperacion>${escapeXml(r.emissionDate)}</FechaOperacion>
    <CodigoConcepto>${escapeXml(r.conceptCode || '001')}</CodigoConcepto>
    <MontoOperacion>${Number(r.taxableBaseBs).toFixed(2)}</MontoOperacion>
    <PorcentajeRetencion>${Number(r.islrRate || 2).toFixed(2)}</PorcentajeRetencion>
  </DetalleRetencion>`).join('\n');

  return `<?xml version="1.0" encoding="ISO-8859-1"?>
<RelacionRetencionesISLR RifAgente="${cleanAgent}" Periodo="${cleanPeriod}">
${itemsXml}
</RelacionRetencionesISLR>`;
}

function buildIslrVoucherNumber(periodYYYYMM, seq = 1) {
  const ym = String(periodYYYYMM || '').replace(/[^0-9]/g, '').slice(0, 6) || '202611';
  return `ARC-${ym}-${String(seq).padStart(6, '0')}`;
}

function resolveIslrConceptInfo(islrRate = 2) {
  const rate = Number(islrRate);
  if (rate === 5) {
    return { code: '055', description: 'Honorarios Profesionales a Personas Jurídicas / Comisiones Mercantiles (5%)' };
  }
  if (rate === 3) {
    return { code: '004', description: 'Honorarios Profesionales Personas Naturales / Fletes y Transportes PJ (3%)' };
  }
  if (rate === 1) {
    return { code: '054', description: 'Ejecución de Obras y Prestación de Servicios por Personas Naturales (1%)' };
  }
  return { code: '053', description: 'Servicios Generales Prestados por Personas Jurídicas (2% Decreto 1808 Art. 9 Num. 11)' };
}

function generateIslrVoucherSummary({
  agentName,
  agentRif,
  supplierName,
  supplierRif,
  invoiceNumber,
  controlNumber,
  emissionDate,
  taxableBaseBs,
  islrRate = 2,
  bcvRate = 914.02,
  seq = 1
}) {
  const period = String(emissionDate || '').replace(/[^0-9]/g, '').slice(0, 6) || '202611';
  const voucherNumber = buildIslrVoucherNumber(period, seq);
  const concept = resolveIslrConceptInfo(islrRate);
  const baseBs = Number(taxableBaseBs || 0);
  const rate = Number(islrRate);
  const withheldBs = Number(((baseBs * rate) / 100).toFixed(2));
  const rateBcv = Number(bcvRate || 914.02);
  const withheldUsd = Number((withheldBs / rateBcv).toFixed(2));
  const baseUsd = Number((baseBs / rateBcv).toFixed(2));

  return {
    voucherNumber,
    period,
    emissionDate: emissionDate || new Date().toISOString().slice(0, 10),
    legalFramework: 'Decreto N° 1.808 (Reglamento Parcial de Retenciones de ISLR · G.O. N° 36.203)',
    agent: {
      name: agentName,
      rif: agentRif
    },
    supplier: {
      name: supplierName,
      rif: supplierRif
    },
    invoice: {
      invoiceNumber,
      controlNumber,
      emissionDate
    },
    conceptCode: concept.code,
    conceptDescription: concept.description,
    taxableBaseBs,
    taxableBaseUsd: baseUsd,
    islrRate: rate,
    withheldBs,
    withheldUsd,
    bcvRate: rateBcv
  };
}

function calculateLotttPayroll({ baseSalaryBs, cestaticketBs = 0, riskLevel = 'MINIMO' }) {
  const ivssEmployee = Number((baseSalaryBs * 0.04).toFixed(2));
  const faovEmployee = Number((baseSalaryBs * 0.01).toFixed(2));
  const rpeEmployee = Number((baseSalaryBs * 0.005).toFixed(2));

  const employerIvssRate = riskLevel === 'ALTO' ? 0.11 : riskLevel === 'MEDIO' ? 0.10 : 0.09;
  const ivssEmployer = Number((baseSalaryBs * employerIvssRate).toFixed(2));
  const faovEmployer = Number((baseSalaryBs * 0.02).toFixed(2));
  const rpeEmployer = Number((baseSalaryBs * 0.02).toFixed(2));
  const incesQuarterlyProvision = Number((baseSalaryBs * 0.02).toFixed(2));

  const dailyIntegral = (baseSalaryBs / 30) * (1 + (30 / 360) + (15 / 360));
  const prestacionesMonthlyProvision = Number((dailyIntegral * 5).toFixed(2));

  const totalDeductions = Number((ivssEmployee + faovEmployee + rpeEmployee).toFixed(2));
  const netPayBs = Number((baseSalaryBs + cestaticketBs - totalDeductions).toFixed(2));

  return {
    baseSalaryBs,
    cestaticketBs,
    deductions: { ivssEmployee, faovEmployee, rpeEmployee, totalDeductions },
    employerContributions: { ivssEmployer, faovEmployer, rpeEmployer, incesQuarterlyProvision, prestacionesMonthlyProvision },
    netPayBs
  };
}

function parseVenezuelanAmount(val) {
  if (typeof val === 'number') return val;
  const clean = String(val || '').trim().replace(/\s/g, '');
  if (!clean) return 0;
  // Format: 1.250,50 or 1250.50
  if (clean.includes(',') && clean.includes('.')) {
    return parseFloat(clean.replace(/\./g, '').replace(',', '.'));
  }
  if (clean.includes(',')) {
    return parseFloat(clean.replace(',', '.'));
  }
  return parseFloat(clean) || 0;
}

function parseBankStatementCsv(csvText, defaultBank = 'BANESCO', tenantId = 'tenant_default') {
  if (!csvText || typeof csvText !== 'string') return [];
  const lines = csvText.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  if (lines.length < 2) return [];

  // Determine delimiter: comma, semicolon, tab
  const headerLine = lines[0];
  let delim = ',';
  if (headerLine.includes('\t')) delim = '\t';
  else if (headerLine.includes(';')) delim = ';';

  const headers = headerLine.split(delim).map(h => h.trim().toUpperCase().replace(/["']/g, ''));

  // Detect bank
  let bank = defaultBank;
  const fullText = csvText.toUpperCase();
  if (fullText.includes('BANCO DE VENEZUELA') || fullText.includes('BDV')) bank = 'BDV';
  else if (fullText.includes('MERCANTIL')) bank = 'MERCANTIL';
  else if (fullText.includes('BANCAMIGA')) bank = 'BANCAMIGA';
  else if (fullText.includes('BANESCO')) bank = 'BANESCO';

  // Find column indices
  let dateIdx = headers.findIndex(h => h.includes('FECHA') || h.includes('DATE'));
  let refIdx = headers.findIndex(h => h.includes('REF') || h.includes('DOCUMENTO') || h.includes('TRANSAC'));
  let descIdx = headers.findIndex(h => h.includes('CONCEPTO') || h.includes('DESCRIP') || h.includes('DETALLE'));
  let amountIdx = headers.findIndex(h => h.includes('MONTO') || h.includes('IMPORTE') || h.includes('VALOR'));
  let debitIdx = headers.findIndex(h => h.includes('DEBITO') || h.includes('CARGO') || h.includes('EGRESO'));
  let creditIdx = headers.findIndex(h => h.includes('CREDITO') || h.includes('ABONO') || h.includes('INGRESO'));

  if (dateIdx === -1) dateIdx = 0;
  if (refIdx === -1) refIdx = 1;
  if (descIdx === -1) descIdx = 2;

  const results = [];

  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(delim).map(c => c.trim().replace(/^["']|["']$/g, ''));
    if (cols.length <= Math.max(dateIdx, descIdx)) continue;

    const rawDate = cols[dateIdx] || '';
    const rawRef = cols[refIdx] || `REF${Date.now()}_${i}`;
    const rawDesc = cols[descIdx] || 'MOVIMIENTO BANCARIO';

    let amount = 0;
    if (amountIdx !== -1 && cols[amountIdx]) {
      amount = parseVenezuelanAmount(cols[amountIdx]);
    } else if (creditIdx !== -1 && debitIdx !== -1) {
      const cr = parseVenezuelanAmount(cols[creditIdx]);
      const db = parseVenezuelanAmount(cols[debitIdx]);
      amount = cr > 0 ? cr : -Math.abs(db);
    } else if (cols[3]) {
      amount = parseVenezuelanAmount(cols[3]);
    }

    if (isNaN(amount) || amount === 0) continue;

    // Movement Type Detection
    const descUpper = rawDesc.toUpperCase();
    let moveType = 'TRANSFERENCIA';
    if (descUpper.includes('PAGO MOVIL') || descUpper.includes('PAGOMOVIL') || descUpper.includes('C2P') || descUpper.includes('P2P') || descUpper.includes('P2C')) {
      moveType = 'PAGO_MOVIL';
    } else if (descUpper.includes('LOTE') || descUpper.includes('POS') || descUpper.includes('PUNTO DE VENTA') || descUpper.includes('TARJ')) {
      moveType = 'CIERRE_LOTE_POS';
    } else if (descUpper.includes('COMISION') || descUpper.includes('MANTENIMIENTO') || descUpper.includes('TARIFA')) {
      moveType = 'COMISION_BANCARIA';
    } else if (descUpper.includes('IGTF') || descUpper.includes('TRANSACCIONES FINANCIERAS')) {
      moveType = 'DEBITO_IGTF';
    } else if (amount > 0) {
      moveType = 'DEPOSITO';
    }

    results.push({
      id: `mov_${bank.toLowerCase()}_${Date.now()}_${i}`,
      tenantId,
      bankName: bank,
      date: rawDate,
      referenceNumber: rawRef.replace(/[^0-9A-Z]/gi, ''),
      description: rawDesc,
      amountBs: amount,
      movementType: moveType,
      reconciliationStatus: 'PENDIENTE'
    });
  }

  return results;
}

function calculateExchangeDifferenceNic21({ invoiceTotalOriginal, invoiceCurrency, invoiceBcvRate, paymentBcvRate, paidAmountBs }) {
  // If invoice was in VES and settled in VES with no USD peg, diff is 0
  if (invoiceCurrency !== 'USD' && (!invoiceBcvRate || invoiceBcvRate === paymentBcvRate)) {
    return { gainOrLoss: 'EXACTO', diffBs: 0, diffPercent: 0, historicalBs: invoiceTotalOriginal, paidBs: paidAmountBs };
  }

  const usdValue = invoiceCurrency === 'USD' ? invoiceTotalOriginal : (invoiceTotalOriginal / invoiceBcvRate);
  const historicalBs = Number((usdValue * invoiceBcvRate).toFixed(2));
  const expectedPaymentBs = Number((usdValue * paymentBcvRate).toFixed(2));
  const actualPaidBs = paidAmountBs !== undefined ? paidAmountBs : expectedPaymentBs;

  const diffBs = Number((actualPaidBs - historicalBs).toFixed(2));
  const diffPercent = historicalBs > 0 ? Number(((diffBs / historicalBs) * 100).toFixed(2)) : 0;

  let gainOrLoss = 'EXACTO';
  if (diffBs > 0.05) gainOrLoss = 'GANANCIA';
  else if (diffBs < -0.05) gainOrLoss = 'PERDIDA';

  return {
    gainOrLoss,
    diffBs,
    diffPercent,
    historicalBs,
    paidBs: actualPaidBs,
    usdValue
  };
}

function breakdownPosSettlementBatch(netDepositBs, feePercent = 1.8, retPercent = 1.5) {
  const net = Number(netDepositBs);
  const totalDeductionRatio = (feePercent + retPercent) / 100;
  const grossSalesBs = Number((net / (1 - totalDeductionRatio)).toFixed(2));
  const bankFeeBs = Number((grossSalesBs * (feePercent / 100)).toFixed(2));
  const seniatRetBs = Number((grossSalesBs * (retPercent / 100)).toFixed(2));

  return {
    grossSalesBs,
    bankFeeBs,
    seniatRetBs,
    netDepositBs: net
  };
}

function runDeterministicBankReconciliation(bankMovements, invoices, currentBcvRate = 914.02) {
  let matchedCount = 0;
  let totalGainCambiariaBs = 0;
  let totalLossCambiariaBs = 0;

  const reconciledMoves = bankMovements.map(m => {
    // If it's already reconciled or a bank fee, process accordingly
    if (m.movementType === 'COMISION_BANCARIA' || m.movementType === 'DEBITO_IGTF') {
      return { ...m, reconciliationStatus: 'CONCILIADO' };
    }

    if (m.movementType === 'CIERRE_LOTE_POS') {
      const breakdown = breakdownPosSettlementBatch(Math.abs(m.amountBs));
      matchedCount++;
      return {
        ...m,
        reconciliationStatus: 'CONCILIADO',
        posBreakdown: breakdown
      };
    }

    // Try matching with an invoice
    // Match criterion 1: Reference number contains or is contained in invoice number / control number
    const cleanRef = String(m.referenceNumber || '').replace(/[^0-9]/g, '');
    let matchedInvoice = invoices.find(inv => {
      const cleanInvNum = String(inv.invoiceNumber || '').replace(/[^0-9]/g, '');
      const cleanCtrl = String(inv.controlNumber || '').replace(/[^0-9]/g, '');
      if (cleanRef.length >= 4 && (cleanInvNum.endsWith(cleanRef) || cleanRef.endsWith(cleanInvNum))) return true;
      if (cleanRef.length >= 4 && (cleanCtrl.endsWith(cleanRef) || cleanRef.endsWith(cleanCtrl))) return true;
      return false;
    });

    // Match criterion 2: Amount match (within 1% in VES, or matching USD converted to current BCV rate)
    if (!matchedInvoice && m.amountBs > 0) {
      matchedInvoice = invoices.find(inv => {
        const invTotalBs = inv.currency === 'USD' ? (inv.totalOriginal * currentBcvRate) : inv.totalOriginal;
        const diff = Math.abs(invTotalBs - m.amountBs);
        // Match if within Bs. 5 or within 0.5%
        return diff < 5 || (diff / invTotalBs) < 0.005;
      });
    }

    if (matchedInvoice) {
      matchedCount++;
      let diffInfo = null;
      if (matchedInvoice.currency === 'USD') {
        diffInfo = calculateExchangeDifferenceNic21({
          invoiceTotalOriginal: matchedInvoice.totalOriginal,
          invoiceCurrency: 'USD',
          invoiceBcvRate: matchedInvoice.bcvRateOnDate || currentBcvRate,
          paymentBcvRate: currentBcvRate,
          paidAmountBs: m.amountBs
        });

        if (diffInfo.gainOrLoss === 'GANANCIA') totalGainCambiariaBs += diffInfo.diffBs;
        if (diffInfo.gainOrLoss === 'PERDIDA') totalLossCambiariaBs += Math.abs(diffInfo.diffBs);
      }

      return {
        ...m,
        reconciliationStatus: diffInfo && diffInfo.diffBs !== 0 ? 'DIFERENCIAL_CAMBIARIO' : 'CONCILIADO',
        matchedInvoiceId: matchedInvoice.id,
        matchedInvoiceNumber: matchedInvoice.invoiceNumber,
        exchangeDiffBs: diffInfo ? diffInfo.diffBs : 0
      };
    }

    return m;
  });

  return {
    reconciledMoves,
    matchedCount,
    pendingCount: reconciledMoves.filter(m => m.reconciliationStatus === 'PENDIENTE').length,
    totalGainCambiariaBs: Number(totalGainCambiariaBs.toFixed(2)),
    totalLossCambiariaBs: Number(totalLossCambiariaBs.toFixed(2))
  };
}

module.exports = {
  validateVenezuelanRIF,
  buildRetentionVoucherNumber,
  generateSeniatIvaTxt16Columns,
  generateIslrDecreto1808Xml,
  buildIslrVoucherNumber,
  resolveIslrConceptInfo,
  generateIslrVoucherSummary,
  calculateLotttPayroll,
  parseBankStatementCsv,
  calculateExchangeDifferenceNic21,
  breakdownPosSettlementBatch,
  runDeterministicBankReconciliation
};
