const { computeAuditHash } = require('./cryptoVault');

const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 30 * 60 * 1000; // 30 minutos de enfriamiento
const TARPIT_ATTEMPTS_THRESHOLD = 3; // A partir del 3er fallo se activa retardo de seguridad

// Almacén en memoria de intentos de login e incidentes
const attemptsMap = new Map();
const incidentsLog = [];

/**
 * Normaliza el identificador de cuenta (correo o usuario)
 */
function normalizeIdentifier(raw) {
  return String(raw || '').trim().toLowerCase();
}

/**
 * Consulta el estado actual de bloqueo de una cuenta o IP
 */
function checkLockStatus(rawIdentifier) {
  const id = normalizeIdentifier(rawIdentifier);
  if (!id) return { isLocked: false, remainingMs: 0, remainingMinutes: 0, attempts: 0, lockedUntil: null };

  const record = attemptsMap.get(id);
  if (!record) {
    return { isLocked: false, remainingMs: 0, remainingMinutes: 0, attempts: 0, lockedUntil: null };
  }

  const now = Date.now();
  if (record.lockedUntil && now < record.lockedUntil.getTime()) {
    const remainingMs = record.lockedUntil.getTime() - now;
    const remainingMinutes = Math.ceil(remainingMs / (60 * 1000));
    return {
      isLocked: true,
      remainingMs,
      remainingMinutes,
      attempts: record.attempts,
      lockedUntil: record.lockedUntil.toISOString()
    };
  }

  // Si el tiempo de bloqueo ya expiró, restablecer automáticamente
  if (record.lockedUntil && now >= record.lockedUntil.getTime()) {
    attemptsMap.delete(id);
    return { isLocked: false, remainingMs: 0, remainingMinutes: 0, attempts: 0, lockedUntil: null };
  }

  return {
    isLocked: false,
    remainingMs: 0,
    remainingMinutes: 0,
    attempts: record.attempts,
    lockedUntil: null
  };
}

/**
 * Registra un intento fallido de autenticación
 */
function recordFailedAttempt(rawIdentifier, ip = '127.0.0.1', meta = {}) {
  const id = normalizeIdentifier(rawIdentifier);
  if (!id) {
    return { isLocked: false, attempts: 0, remainingAttempts: MAX_FAILED_ATTEMPTS, lockedUntil: null };
  }

  const existing = attemptsMap.get(id) || {
    attempts: 0,
    firstAttemptAt: new Date(),
    lockedUntil: null,
    ipHistory: []
  };

  existing.attempts += 1;
  existing.lastAttemptAt = new Date();
  if (!existing.ipHistory.includes(ip)) {
    existing.ipHistory.push(ip);
  }

  const now = Date.now();
  let incident = null;

  if (existing.attempts >= MAX_FAILED_ATTEMPTS) {
    existing.lockedUntil = new Date(now + LOCKOUT_DURATION_MS);
    
    // Crear incidente criptográfico de auditoría forense
    const prevIncidentHash = incidentsLog.length > 0 ? incidentsLog[incidentsLog.length - 1].hash : 'GENESIS_SEC_LOCK_2026';
    const incidentData = {
      type: 'ACCOUNT_LOCKED_BRUTE_FORCE',
      identifier: id,
      attempts: existing.attempts,
      ip,
      lockedUntil: existing.lockedUntil.toISOString(),
      timestamp: new Date().toISOString()
    };

    incident = {
      id: `inc_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      ...incidentData,
      hash: computeAuditHash(prevIncidentHash, incidentData)
    };
    incidentsLog.push(incident);
  }

  attemptsMap.set(id, existing);

  const remainingAttempts = Math.max(0, MAX_FAILED_ATTEMPTS - existing.attempts);
  const isLocked = existing.attempts >= MAX_FAILED_ATTEMPTS;

  return {
    isLocked,
    attempts: existing.attempts,
    remainingAttempts,
    lockedUntil: existing.lockedUntil ? existing.lockedUntil.toISOString() : null,
    shouldTarpit: existing.attempts >= TARPIT_ATTEMPTS_THRESHOLD,
    incident
  };
}

/**
 * Restablece los intentos tras un inicio de sesión exitoso
 */
function recordSuccessfulLogin(rawIdentifier) {
  const id = normalizeIdentifier(rawIdentifier);
  if (!id) return;
  attemptsMap.delete(id);
}

/**
 * Desbloqueo manual emitido por un Super-Administrador
 */
function manualUnlock(rawIdentifier, adminUid = 'superadmin') {
  const id = normalizeIdentifier(rawIdentifier);
  if (!id) return { success: false, error: 'Identificador requerido' };

  const existed = attemptsMap.has(id);
  attemptsMap.delete(id);

  const prevIncidentHash = incidentsLog.length > 0 ? incidentsLog[incidentsLog.length - 1].hash : 'GENESIS_SEC_UNLOCK_2026';
  const unlockData = {
    type: 'MANUAL_ACCOUNT_UNLOCK',
    identifier: id,
    unlockedBy: adminUid,
    timestamp: new Date().toISOString()
  };

  const auditEntry = {
    id: `unl_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    ...unlockData,
    hash: computeAuditHash(prevIncidentHash, unlockData)
  };
  incidentsLog.push(auditEntry);

  return {
    success: true,
    identifier: id,
    existed,
    unlockedBy: adminUid,
    unlockedAt: unlockData.timestamp,
    auditHash: auditEntry.hash
  };
}

/**
 * Retorna todos los incidentes y cuentas actualmente bloqueadas
 */
function listSecurityIncidents() {
  const now = Date.now();
  const activeLocks = [];

  for (const [id, rec] of attemptsMap.entries()) {
    if (rec.lockedUntil && rec.lockedUntil.getTime() > now) {
      activeLocks.push({
        identifier: id,
        attempts: rec.attempts,
        lockedUntil: rec.lockedUntil.toISOString(),
        remainingMinutes: Math.ceil((rec.lockedUntil.getTime() - now) / (60 * 1000)),
        ips: rec.ipHistory,
        lastAttemptAt: rec.lastAttemptAt.toISOString()
      });
    }
  }

  return {
    activeLocks,
    incidentsHistory: incidentsLog.slice(-50).reverse()
  };
}

/**
 * Limpia el estado interno (utilidad exclusiva para tests)
 */
function resetStateForTests() {
  attemptsMap.clear();
  incidentsLog.length = 0;
}

module.exports = {
  MAX_FAILED_ATTEMPTS,
  LOCKOUT_DURATION_MS,
  TARPIT_ATTEMPTS_THRESHOLD,
  checkLockStatus,
  recordFailedAttempt,
  recordSuccessfulLogin,
  manualUnlock,
  listSecurityIncidents,
  resetStateForTests
};
