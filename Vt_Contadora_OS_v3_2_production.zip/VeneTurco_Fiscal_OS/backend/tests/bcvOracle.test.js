const test = require('node:test');
const assert = require('node:assert');
const { syncOfficialBcvRate, DEFAULT_CURRENT_BCV_USD, DEFAULT_CURRENT_BCV_EUR } = require('../services/bcvSyncCron');

test('Oráculo BCV: Sincronización oficial multi-fuente y resiliencia macroeconómica', async () => {
  // Mock DB in-memory
  const mockDb = {
    collection: () => ({
      doc: () => ({
        set: async () => {},
        get: async () => ({ exists: false })
      }),
      orderBy: () => ({
        limit: () => ({
          get: async () => ({ empty: true })
        })
      })
    })
  };

  const rateResult = await syncOfficialBcvRate(mockDb);
  assert.ok(rateResult, 'Debe retornar un objeto de tasa');
  assert.ok(typeof rateResult.usdVes === 'number', 'usdVes debe ser numérico');
  assert.ok(rateResult.usdVes > 100, `La tasa oficial USD/VES debe reflejar la economía real venezolana (>100 Bs): ${rateResult.usdVes}`);
  assert.ok(typeof rateResult.eurVes === 'number', 'eurVes debe ser numérico');
  assert.ok(rateResult.eurVes > rateResult.usdVes, 'La tasa EUR/VES debe ser mayor a la tasa USD/VES');
  assert.ok(rateResult.date, 'Debe incluir fecha valor');
  assert.ok(rateResult.source, 'Debe incluir origen de datos verificado');
});
