import React from 'react';
import { CheckCircle2, Sparkles } from 'lucide-react';

interface AppleSkeletonProps {
  variant?: 'card' | 'row' | 'text';
  count?: number;
  className?: string;
}

export const AppleSkeleton: React.FC<AppleSkeletonProps> = ({
  variant = 'card',
  count = 1,
  className = ''
}) => {
  const items = Array.from({ length: count });

  if (variant === 'row') {
    return (
      <div className={`space-y-2.5 ${className}`}>
        {items.map((_, idx) => (
          <div
            key={idx}
            className="h-12 w-full rounded-xl bg-white/[0.04] border border-white/[0.06] animate-pulse flex items-center justify-between px-4"
          >
            <div className="h-3 w-1/4 rounded bg-white/10" />
            <div className="h-3 w-1/3 rounded bg-white/10" />
            <div className="h-5 w-16 rounded-full bg-white/10" />
          </div>
        ))}
      </div>
    );
  }

  if (variant === 'text') {
    return (
      <div className={`space-y-2 ${className}`}>
        {items.map((_, idx) => (
          <div key={idx} className="h-3.5 rounded bg-white/10 animate-pulse w-full" />
        ))}
      </div>
    );
  }

  return (
    <div className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 ${className}`}>
      {items.map((_, idx) => (
        <div
          key={idx}
          className="p-5 rounded-2xl bg-white/[0.03] border border-white/[0.07] animate-pulse space-y-3 shadow-[inset_0_1px_0_0_rgba(255,255,255,0.08)]"
        >
          <div className="flex items-center justify-between">
            <div className="h-3 w-24 rounded bg-white/10" />
            <div className="h-5 w-14 rounded-full bg-white/10" />
          </div>
          <div className="h-7 w-32 rounded bg-white/15" />
          <div className="h-3 w-40 rounded bg-white/[0.08]" />
        </div>
      ))}
    </div>
  );
};

interface AppleEmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
}

export const AppleEmptyState: React.FC<AppleEmptyStateProps> = ({
  icon,
  title,
  description,
  actionLabel,
  onAction
}) => (
  <div className="ui-card p-8 text-center flex flex-col items-center justify-center space-y-3 border border-white/10 bg-white/[0.02]">
    <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/25 flex items-center justify-center text-emerald-400 shadow-[inset_0_1px_0_0_rgba(255,255,255,0.15)]">
      {icon || <Sparkles className="w-5 h-5" />}
    </div>
    <div className="max-w-md space-y-1">
      <h4 className="text-sm font-bold text-white tracking-tight">{title}</h4>
      <p className="text-xs text-white/60 leading-relaxed">{description}</p>
    </div>
    {actionLabel && onAction && (
      <button
        onClick={onAction}
        className="mt-1 px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-all active:scale-[0.97] shadow"
      >
        {actionLabel}
      </button>
    )}
  </div>
);

interface ApplePipelineStepperProps {
  steps: string[];
  activeIndex: number;
}

export const ApplePipelineStepper: React.FC<ApplePipelineStepperProps> = ({ steps, activeIndex }) => (
  <div className="flex flex-wrap items-center gap-2 p-3 rounded-xl bg-black/35 border border-white/10">
    {steps.map((step, idx) => {
      const done = idx < activeIndex;
      const active = idx === activeIndex;
      return (
        <div key={step} className="flex items-center gap-2 text-xs font-mono">
          <span
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition-all duration-300 ${
              done
                ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                : active
                ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-400/40 animate-pulse font-bold'
                : 'bg-white/[0.03] text-white/40 border border-white/5'
            }`}
          >
            {done ? <CheckCircle2 className="w-3.5 h-3.5" /> : <span>{idx + 1}.</span>}
            <span>{step}</span>
          </span>
          {idx < steps.length - 1 && <span className="text-white/25">➔</span>}
        </div>
      );
    })}
  </div>
);
