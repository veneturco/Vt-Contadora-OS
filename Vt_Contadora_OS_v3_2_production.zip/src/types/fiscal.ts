export type SkinId =
  | 'apple-craft-pro'
  | 'obsidian-linear'
  | 'mercury-sovereign'
  | 'spatial-titanium'
  | 'tactile-bento'
  | 'hyperframe-tactical'
  | 'kinetic-studio'
  | 'editorial-swiss'
  | 'eink-auditor'
  | 'neo-brutal';

export type ActiveTabId =
  | 'accountants'
  | 'clients'
  | 'simplified'
  | 'command'
  | 'ocr'
  | 'books'
  | 'payroll'
  | 'saas'
  | 'reconciliation'
  | 'mobile'
  | 'security'
  | 'operations';

export type OperationStepId = 'scanner' | 'books' | 'reconciliation';

export interface Tenant {
  id: string;
  name: string;
  rif: string;
  regime: 'SPE' | 'ORDINARIO' | 'FORMAL';
  planId: 'COMERCIO_PRO' | 'EMPRESA_MAX' | 'FIRMA_CONTABLE';
  subscriptionStatus: 'ACTIVA' | 'SUSPENDIDA';
  nextBillingDate: string;
  telegramCode: string;
  telegramChatLinked?: string;
  // Sub-cuenta de empresa (Monetización SaaS B2B2B)
  subAccountEnabled?: boolean;
  subAccountContactName?: string;
  subAccountPhone?: string;
  subAccountEmail?: string;
  subAccountRole?: 'OPERADOR_CAJA' | 'ADMIN_EMPRESA' | 'SOLO_CONSULTA';
  subAccountStatus?: 'TRIAL_15_DIAS' | 'ACTIVA' | 'POR_VENCER' | 'SUSPENDIDA';
  trialDaysLeft?: number;
  monthlyFeeUsd?: number;
  accountantCommissionPercent?: number;
}

export interface AccountantPartner {
  id: string;
  name: string;
  cpcNumber: string;
  rif: string;
  email: string;
  phone: string;
  city: string;
  planId: 'CONTADOR_INDIVIDUAL' | 'FIRMA_PRO' | 'CONSORCIO_MAX';
  monthlyFeeUsd: number;
  maxCompaniesLimit: number;
  assignedTenantIds: string[];
  subscriptionStatus: 'ACTIVA' | 'SUSPENDIDA' | 'EN_PRUEBA';
  nextBillingDate: string;
  payoutMethod: 'PAGO_MOVIL' | 'BINANCE_PAY' | 'ZELLE';
  payoutDetails: string;
  pendingCommissionUsd: number;
  paidCommissionsTotalUsd: number;
  firmLogoText?: string;
  createdAt: string;
}

export const SKINS: { id: SkinId; label: string }[] = [
  { id: 'apple-craft-pro', label: ' Apple Craft Pro (Emil Kowalski)' },
  { id: 'obsidian-linear', label: 'Obsidian Linear' },
  { id: 'mercury-sovereign', label: 'Mercury Sovereign (Fintech 2026)' },
  { id: 'spatial-titanium', label: 'Liquid Glass Titanium (Spatial)' },
  { id: 'tactile-bento', label: 'Tactile Hardware Bento' },
  { id: 'hyperframe-tactical', label: 'Hyperframe HUD (Tactical)' },
  { id: 'kinetic-studio', label: 'Kinetic Studio (Volt)' },
  { id: 'editorial-swiss', label: 'Editorial Swiss Ledger' },
  { id: 'eink-auditor', label: 'E-Ink Paper Audit (No-Glare)' },
  { id: 'neo-brutal', label: 'Neo-Brutalist Raw' }
];
