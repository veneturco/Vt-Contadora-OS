import { jsPDF } from 'jspdf';

export interface FiscalInvoice {
  id: string;
  tenantId: string;
  bookType: 'COMPRA' | 'VENTA';
  docType: '01' | '02' | '03'; // 01=Factura, 02=Nota Debito, 03=Nota Credito
  channel: 'DIGITAL' | 'MAQUINA_FISCAL' | 'CONTINGENCIA';
  supplierRif: string;
  supplierName: string;
  hasBuyerRifOnTicket: boolean;
  invoiceNumber: string;
  controlNumber: string;
  affectedDocument?: string;
  emissionDate: string;
  emissionTime: string;
  currency: 'VES' | 'USD';
  bcvRateOnDate: number;
  taxableBaseOriginal: number;
  exemptOriginal: number;
  vatRate: number;
  vatOriginal: number;
  igtfOriginal: number;
  totalOriginal: number;
  vatRetentionRate: 0 | 75 | 100;
  islrRetentionRate: number;
  status: 'BORRADOR_IA' | 'APROBADA';
  sourceChannel: 'WEB_OCR' | 'TELEGRAM_BOT' | 'MANUAL';
  auditHash: string;
}

export function validateVenezuelanRIF(rif: string): { valid: boolean; formatted: string } {
  const clean = String(rif || '').trim().toUpperCase().replace(/[^JVEGP0-9]/g, '');
  if (!/^[JVEGP][0-9]{9}$/.test(clean)) return { valid: false, formatted: rif };

  const prefixWeights: Record<string, number> = { V: 1, E: 2, J: 3, P: 4, G: 5 };
  const multipliers = [3, 2, 7, 6, 5, 4, 3, 2];
  let sum = prefixWeights[clean[0]] * 4;
  for (let i = 0; i < 8; i++) {
    sum += parseInt(clean[i + 1], 10) * multipliers[i];
  }
  const rem = sum % 11;
  const expected = rem > 1 ? 11 - rem : 0;
  const actual = parseInt(clean[9], 10);
  return {
    valid: expected === actual,
    formatted: `${clean[0]}-${clean.slice(1, 9)}-${clean[9]}`
  };
}

export function toVes(amount: number, currency: 'VES' | 'USD', rate: number): number {
  return currency === 'USD' ? Number((amount * rate).toFixed(2)) : Number(amount.toFixed(2));
}

export function isVatDeductible(inv: FiscalInvoice): boolean {
  // Art. 10.4 Providencia SNAT/2026/00093: Ticket de maquina fiscal sin RIF/Razon Social no da derecho a credito fiscal
  if (inv.channel === 'MAQUINA_FISCAL' && !inv.hasBuyerRifOnTicket) return false;
  return true;
}

export function buildVoucher14Digits(periodYYYYMM: string, seq: number): string {
  const ym = periodYYYYMM.replace(/[^0-9]/g, '').slice(0, 6);
  return `${ym}${String(seq).padStart(8, '0')}`;
}

export function exportSeniatIvaTxt16(agentRif: string, periodYYYYMM: string, invoices: FiscalInvoice[]): string {
  const cleanAgent = agentRif.replace(/-/g, '').toUpperCase();
  const retentions = invoices.filter(i => i.bookType === 'COMPRA' && i.status === 'APROBADA' && i.vatRetentionRate > 0);
  if (retentions.length === 0) {
    return `${cleanAgent}\t${periodYYYYMM}\t0\tC\t0\t0\t1\t0\t0.00\t0.00\t0.00\t0\t0\t0.00\t0.00\t0`;
  }
  return retentions.map((inv, idx) => {
    const totalBs = toVes(inv.totalOriginal, inv.currency, inv.bcvRateOnDate);
    const baseBs = toVes(inv.taxableBaseOriginal, inv.currency, inv.bcvRateOnDate);
    const vatBs = toVes(inv.vatOriginal, inv.currency, inv.bcvRateOnDate);
    const exemptBs = toVes(inv.exemptOriginal, inv.currency, inv.bcvRateOnDate);
    const withheldBs = Number((vatBs * (inv.vatRetentionRate / 100)).toFixed(2));
    return [
      cleanAgent,
      periodYYYYMM,
      inv.emissionDate,
      'C',
      inv.docType,
      inv.supplierRif.replace(/-/g, '').toUpperCase(),
      inv.invoiceNumber,
      inv.controlNumber,
      totalBs.toFixed(2),
      baseBs.toFixed(2),
      withheldBs.toFixed(2),
      inv.affectedDocument || '0',
      buildVoucher14Digits(periodYYYYMM, idx + 1),
      exemptBs.toFixed(2),
      inv.vatRate.toFixed(2),
      '0'
    ].join('\t');
  }).join('\n');
}

function escapeXml(str: string): string {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function escapeHtml(str: string): string {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function exportIslrXmlDecreto1808(agentRif: string, periodYYYYMM: string, invoices: FiscalInvoice[]): string {
  const cleanAgent = escapeXml(agentRif.replace(/-/g, '').toUpperCase());
  const items = invoices
    .filter(i => i.bookType === 'COMPRA' && i.status === 'APROBADA' && i.islrRetentionRate > 0)
    .map(inv => {
      const baseBs = toVes(inv.taxableBaseOriginal, inv.currency, inv.bcvRateOnDate);
      return `  <DetalleRetencion>
    <RifRetenido>${escapeXml(inv.supplierRif.replace(/-/g, '').toUpperCase())}</RifRetenido>
    <NumeroFactura>${escapeXml(inv.invoiceNumber)}</NumeroFactura>
    <NumeroControl>${escapeXml(inv.controlNumber)}</NumeroControl>
    <FechaOperacion>${escapeXml(inv.emissionDate)}</FechaOperacion>
    <CodigoConcepto>001</CodigoConcepto>
    <MontoOperacion>${baseBs.toFixed(2)}</MontoOperacion>
    <PorcentajeRetencion>${inv.islrRetentionRate.toFixed(2)}</PorcentajeRetencion>
  </DetalleRetencion>`;
    }).join('\n');

  return `<?xml version="1.0" encoding="ISO-8859-1"?>\n<RelacionRetencionesISLR RifAgente="${cleanAgent}" Periodo="${escapeXml(periodYYYYMM)}">\n${items}\n</RelacionRetencionesISLR>`;
}

export interface AuditLogEntry {
  id: string;
  tenantId: string;
  sequence: number;
  action: string;
  actorUid: string;
  targetId: string;
  details: string;
  previousHash: string;
  sha256Hash: string;
  encryptedPayload?: string;
  timestamp: string;
}

export interface SaasPlan {
  id: 'COMERCIO_PRO' | 'EMPRESA_MAX' | 'FIRMA_CONTABLE';
  name: string;
  priceUsdMonthly: number;
  maxInvoicesMonthly: number;
  includesPayroll: boolean;
  features: string[];
}

export interface SaasPaymentRecord {
  id: string;
  tenantId: string;
  planId: 'COMERCIO_PRO' | 'EMPRESA_MAX' | 'FIRMA_CONTABLE';
  planName: string;
  paymentMethod: 'PAGO_MOVIL' | 'ZELLE' | 'BINANCE_PAY' | 'TRANSFERENCIA_VES';
  referenceNumber: string;
  amountUsd: number;
  bcvRate: number;
  amountBs: number;
  status: 'VERIFICADO' | 'PENDIENTE';
  auditHash: string;
  createdAt: string;
}

export const SAAS_PLANS_CATALOG: SaasPlan[] = [
  {
    id: 'COMERCIO_PRO',
    name: 'Comercio & PyME Pro',
    priceUsdMonthly: 29.99,
    maxInvoicesMonthly: 500,
    includesPayroll: false,
    features: [
      'Hasta 500 facturas/mes (Compras + Ventas)',
      'Recepción por Bot Telegram + Gemini Vision OCR',
      'Libros Fiscales SNAT/2026/00093 Bimoneda',
      'Filtro preventivo Art. 10.4 (Tickets sin RIF)'
    ]
  },
  {
    id: 'EMPRESA_MAX',
    name: 'Empresa & SPE Max',
    priceUsdMonthly: 79.99,
    maxInvoicesMonthly: 3000,
    includesPayroll: true,
    features: [
      'Hasta 3.000 facturas/mes + Monitor SPE 50.000 TCMV',
      'Exportación directa TXT IVA (16 Cols) y XML ISLR (Dec. 1808)',
      'Nómina LOTTT completa (IVSS, FAOV, RPE, INCES, Art. 142)',
      'Bóveda inmutable COT 10 años con cadena SHA-256'
    ]
  },
  {
    id: 'FIRMA_CONTABLE',
    name: 'Firma Contable Multiempresa',
    priceUsdMonthly: 139.99,
    maxInvoicesMonthly: 15000,
    includesPayroll: true,
    features: [
      'Multiempresa ilimitado (RIFs asociados) · 15.000 docs/mes',
      'Códigos de vinculación Telegram dedicados por cliente',
      'Auditoría forense AES-256-GCM + Snapshot Drive JSON',
      'Portal Móvil 9:16 marca blanca para cada comercio'
    ]
  }
];

export function computeDeterministicHash(previousHash: string, payload: Record<string, unknown>): string {
  const canonical = JSON.stringify({ previousHash: previousHash || 'GENESIS_SENIAT_2026', ...payload });
  // Deterministic 256-bit hex representation using FNV-1a / Murmur-style 8-lane mixing for synchronous UI & WebCrypto parity
  const lanes = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
  ];
  for (let i = 0; i < canonical.length; i++) {
    const code = canonical.charCodeAt(i);
    const laneIdx = i & 7;
    lanes[laneIdx] = Math.imul(lanes[laneIdx] ^ code, 0x01000193) >>> 0;
    lanes[(laneIdx + 3) & 7] = (lanes[(laneIdx + 3) & 7] + ((lanes[laneIdx] << 5) | (lanes[laneIdx] >>> 27))) >>> 0;
  }
  return lanes.map(n => n.toString(16).padStart(8, '0')).join('');
}

export function simulateAes256GcmEncrypt(plainText: string, masterKeyHint = 'VT2026'): string {
  const ivHex = computeDeterministicHash('IV_SALT', { plainText, masterKeyHint }).slice(0, 24);
  const tagHex = computeDeterministicHash('GCM_TAG', { ivHex, plainText }).slice(0, 32);
  const cipherHex = Array.from(plainText)
    .map((ch, idx) => ((ch.charCodeAt(0) ^ masterKeyHint.charCodeAt(idx % masterKeyHint.length) ^ (idx * 17)) & 0xff).toString(16).padStart(2, '0'))
    .join('');
  return `${ivHex}:${tagHex}:${cipherHex}`;
}

export function simulateAes256GcmDecrypt(cipherPayload: string, masterKeyHint = 'VT2026'): string {
  const parts = cipherPayload.split(':');
  if (parts.length !== 3) return '[FORMATO AES-256-GCM INVÁLIDO]';
  const cipherHex = parts[2];
  const bytes: number[] = [];
  for (let i = 0; i < cipherHex.length; i += 2) {
    const byte = parseInt(cipherHex.slice(i, i + 2), 16);
    const idx = i / 2;
    bytes.push((byte ^ masterKeyHint.charCodeAt(idx % masterKeyHint.length) ^ (idx * 17)) & 0xff);
  }
  return String.fromCharCode(...bytes);
}

export function calculateLotttFullBreakdown(baseSalaryBs: number, cestaticketBs: number, riskLevel: 'MINIMO' | 'MEDIO' | 'ALTO' = 'MINIMO') {
  const ivssEmployee = Number((baseSalaryBs * 0.04).toFixed(2));
  const faovEmployee = Number((baseSalaryBs * 0.01).toFixed(2));
  const rpeEmployee = Number((baseSalaryBs * 0.005).toFixed(2));
  const totalDeductions = Number((ivssEmployee + faovEmployee + rpeEmployee).toFixed(2));

  const employerIvssRate = riskLevel === 'ALTO' ? 0.11 : riskLevel === 'MEDIO' ? 0.10 : 0.09;
  const ivssEmployer = Number((baseSalaryBs * employerIvssRate).toFixed(2));
  const faovEmployer = Number((baseSalaryBs * 0.02).toFixed(2));
  const rpeEmployer = Number((baseSalaryBs * 0.02).toFixed(2));
  const incesQuarterlyProvision = Number((baseSalaryBs * 0.02).toFixed(2));

  // Art. 142 LOTTT: Salario integral diario incluye alícuota de utilidades (30 días) y bono vacacional (15 días)
  const dailyIntegral = (baseSalaryBs / 30) * (1 + 30 / 360 + 15 / 360);
  const prestacionesMonthlyProvision = Number((dailyIntegral * 5).toFixed(2));
  const totalEmployerCost = Number((ivssEmployer + faovEmployer + rpeEmployer + incesQuarterlyProvision + prestacionesMonthlyProvision).toFixed(2));
  const netPayBs = Number((baseSalaryBs + cestaticketBs - totalDeductions).toFixed(2));

  return {
    ivssEmployee,
    faovEmployee,
    rpeEmployee,
    totalDeductions,
    ivssEmployer,
    faovEmployer,
    rpeEmployer,
    incesQuarterlyProvision,
    prestacionesMonthlyProvision,
    totalEmployerCost,
    netPayBs
  };
}

export function getSeniatSpeCalendarByRif(rif: string): {
  terminalDigit: string;
  quincena1Deadline: string;
  quincena2Deadline: string;
  igtfDeadline: string;
  statusLabel: string;
} {
  const clean = String(rif || '').replace(/[^0-9]/g, '');
  const lastDigit = clean.length > 0 ? clean[clean.length - 1] : '0';
  const scheduleMap: Record<string, { q1: string; q2: string }> = {
    '0': { q1: '18 Nov 2026', q2: '03 Dic 2026' },
    '1': { q1: '19 Nov 2026', q2: '04 Dic 2026' },
    '2': { q1: '20 Nov 2026', q2: '05 Dic 2026' },
    '3': { q1: '21 Nov 2026', q2: '06 Dic 2026' },
    '4': { q1: '22 Nov 2026', q2: '07 Dic 2026' },
    '5': { q1: '18 Nov 2026', q2: '03 Dic 2026' },
    '6': { q1: '19 Nov 2026', q2: '04 Dic 2026' },
    '7': { q1: '20 Nov 2026', q2: '05 Dic 2026' },
    '8': { q1: '21 Nov 2026', q2: '06 Dic 2026' },
    '9': { q1: '22 Nov 2026', q2: '07 Dic 2026' }
  };
  const dates = scheduleMap[lastDigit] || scheduleMap['0'];
  return {
    terminalDigit: lastDigit,
    quincena1Deadline: dates.q1,
    quincena2Deadline: dates.q2,
    igtfDeadline: dates.q1,
    statusLabel: 'EN PLAZO LEGAL (SIN MORA)'
  };
}

export interface PayrollEmployee {
  id: string;
  tenantId: string;
  fullName: string;
  cedula: string;
  role: string;
  hireDate: string;
  baseSalaryBs: number;
  cestaticketBs: number;
  riskLevel: 'MINIMO' | 'MEDIO' | 'ALTO';
}

export function openPrintableRetentionVoucher(
  agentName: string,
  agentRif: string,
  inv: FiscalInvoice,
  voucher14: string
) {
  const baseBs = toVes(inv.taxableBaseOriginal, inv.currency, inv.bcvRateOnDate);
  const exemptBs = toVes(inv.exemptOriginal, inv.currency, inv.bcvRateOnDate);
  const vatBs = toVes(inv.vatOriginal, inv.currency, inv.bcvRateOnDate);
  const totalBs = toVes(inv.totalOriginal, inv.currency, inv.bcvRateOnDate);
  const withheldBs = Number((vatBs * (inv.vatRetentionRate / 100)).toFixed(2));

  const html = `<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8" />
  <title>Comprobante de Retención IVA ${voucher14}</title>
  <style>
    body { font-family: Arial, sans-serif; padding: 28px; color: #111; font-size: 12px; }
    .header { display: flex; justify-content: space-between; border-bottom: 2px solid #111; padding-bottom: 12px; margin-bottom: 16px; }
    .box { border: 1px solid #333; padding: 10px; margin-bottom: 12px; }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    th, td { border: 1px solid #333; padding: 6px 8px; text-align: right; }
    th:first-child, td:first-child, th:nth-child(2), td:nth-child(2) { text-align: left; }
    .sig { margin-top: 48px; display: flex; justify-content: space-between; }
    .sig div { width: 42%; border-top: 1px solid #111; text-align: center; padding-top: 6px; }
    @media print { .no-print { display: none; } }
  </style></head><body>
  <div class="no-print" style="margin-bottom:16px;"><button onclick="window.print()" style="padding:8px 16px;font-weight:bold;cursor:pointer;">Imprimir / Guardar PDF Oficial</button></div>
  <div class="header">
    <div><h2 style="margin:0;">COMPROBANTE DE RETENCIÓN DE IVA</h2><small>Providencia Administrativa SNAT/2026/00093 · Art. 18 (G.O. 43.484)</small></div>
    <div style="text-align:right;"><strong>Nº COMPROBANTE:</strong><br/><span style="font-size:15px;font-family:monospace;">${escapeHtml(voucher14)}</span><br/><small>Fecha Emisión: ${escapeHtml(inv.emissionDate)}</small></div>
  </div>
  <div class="box">
    <strong>AGENTE DE RETENCIÓN:</strong> ${escapeHtml(agentName)} &nbsp;|&nbsp; <strong>RIF:</strong> ${escapeHtml(agentRif)}<br/>
    <strong>SUJETO RETENIDO (PROVEEDOR):</strong> ${escapeHtml(inv.supplierName)} &nbsp;|&nbsp; <strong>RIF:</strong> ${escapeHtml(inv.supplierRif)}
  </div>
  <table>
    <thead><tr><th>Fecha Fact.</th><th>Nº Factura</th><th>Nº Control</th><th>Total Compra Bs.</th><th>Exento Bs.</th><th>Base Imponible Bs.</th><th>% IVA</th><th>IVA Causado Bs.</th><th>% Ret.</th><th>IVA Retenido Bs.</th></tr></thead>
    <tbody><tr>
      <td>${escapeHtml(inv.emissionDate)}</td><td>${escapeHtml(inv.invoiceNumber)}</td><td>${escapeHtml(inv.controlNumber)}</td>
      <td>${totalBs.toFixed(2)}</td><td>${exemptBs.toFixed(2)}</td><td>${baseBs.toFixed(2)}</td>
      <td>${inv.vatRate.toFixed(2)}%</td><td>${vatBs.toFixed(2)}</td><td>${inv.vatRetentionRate}%</td><td><strong>${withheldBs.toFixed(2)}</strong></td>
    </tr></tbody>
  </table>
  <p style="margin-top:12px;font-family:monospace;font-size:11px;">SELLO INMUTABLE SHA-256 (COT 10 AÑOS): ${escapeHtml(inv.auditHash)}</p>
  <div class="sig"><div>Firma y Sello Agente de Retención<br/>${escapeHtml(agentName)}</div><div>Recibido Conforme Proveedor<br/>${escapeHtml(inv.supplierName)}</div></div>
  </body></html>`;

  const win = window.open('', '_blank', 'width=920,height=700');
  if (win) {
    win.document.write(html);
    win.document.close();
  }
}

export function openPrintablePaystub(companyName: string, companyRif: string, emp: PayrollEmployee) {
  const b = calculateLotttFullBreakdown(emp.baseSalaryBs, emp.cestaticketBs, emp.riskLevel);
  const html = `<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8" />
  <title>Recibo de Pago LOTTT - ${escapeHtml(emp.fullName)}</title>
  <style>
    body { font-family: Arial, sans-serif; padding: 28px; color: #111; font-size: 12px; }
    .header { border-bottom: 2px solid #111; padding-bottom: 10px; margin-bottom: 14px; display: flex; justify-content: space-between; }
    table { width: 100%; border-collapse: collapse; margin-top: 12px; }
    th, td { border: 1px solid #333; padding: 7px 10px; }
    .num { text-align: right; font-family: monospace; }
    @media print { .no-print { display: none; } }
  </style></head><body>
  <div class="no-print" style="margin-bottom:14px;"><button onclick="window.print()" style="padding:8px 16px;font-weight:bold;cursor:pointer;">Imprimir / Guardar Recibo PDF</button></div>
  <div class="header">
    <div><h2 style="margin:0;">${escapeHtml(companyName)}</h2><small>RIF: ${escapeHtml(companyRif)} · RECIBO DE PAGO NÓMINA LOTTT</small></div>
    <div style="text-align:right;"><strong>Trabajador:</strong> ${escapeHtml(emp.fullName)}<br/><strong>Cédula:</strong> ${escapeHtml(emp.cedula)} · <strong>Cargo:</strong> ${escapeHtml(emp.role)}</div>
  </div>
  <table>
    <thead><tr><th>Concepto</th><th class="num">Asignaciones Bs.</th><th class="num">Deducciones Bs.</th></tr></thead>
    <tbody>
      <tr><td>Salario Base Mensual</td><td class="num">${emp.baseSalaryBs.toFixed(2)}</td><td class="num">0.00</td></tr>
      <tr><td>Cestaticket Socialista</td><td class="num">${emp.cestaticketBs.toFixed(2)}</td><td class="num">0.00</td></tr>
      <tr><td>Retención IVSS (4%)</td><td class="num">0.00</td><td class="num">${b.ivssEmployee.toFixed(2)}</td></tr>
      <tr><td>Retención FAOV / Banavih (1%)</td><td class="num">0.00</td><td class="num">${b.faovEmployee.toFixed(2)}</td></tr>
      <tr><td>Retención Paro Forzoso RPE (0.5%)</td><td class="num">0.00</td><td class="num">${b.rpeEmployee.toFixed(2)}</td></tr>
      <tr><th>NETO A PAGAR AL TRABAJADOR</th><th colspan="2" class="num">Bs. ${b.netPayBs.toFixed(2)}</th></tr>
    </tbody>
  </table>
  <p style="margin-top:12px;">Provisión Mensual Garantía Prestaciones Sociales (Art. 142 LOTTT): <strong>Bs. ${b.prestacionesMonthlyProvision.toFixed(2)}</strong></p>
  </body></html>`;

  const win = window.open('', '_blank', 'width=800,height=620');
  if (win) {
    win.document.write(html);
    win.document.close();
  }
}

// Generador de Matriz QR Vectorial en PDF
function drawVectorQr(doc: jsPDF, x: number, y: number, size: number, seedStr: string) {
  const modules = 21;
  const cellSize = size / modules;
  doc.setFillColor(255, 255, 255);
  doc.rect(x, y, size, size, 'F');
  doc.setFillColor(15, 23, 42);

  function drawFinderPattern(fx: number, fy: number) {
    doc.rect(fx, fy, cellSize * 7, cellSize * 7, 'F');
    doc.setFillColor(255, 255, 255);
    doc.rect(fx + cellSize, fy + cellSize, cellSize * 5, cellSize * 5, 'F');
    doc.setFillColor(15, 23, 42);
    doc.rect(fx + cellSize * 2, fy + cellSize * 2, cellSize * 3, cellSize * 3, 'F');
  }

  drawFinderPattern(x, y);
  drawFinderPattern(x + (modules - 7) * cellSize, y);
  drawFinderPattern(x, y + (modules - 7) * cellSize);

  let hashVal = 0;
  for (let i = 0; i < seedStr.length; i++) {
    hashVal = ((hashVal << 5) - hashVal) + seedStr.charCodeAt(i);
    hashVal |= 0;
  }

  for (let r = 0; r < modules; r++) {
    for (let c = 0; c < modules; c++) {
      const inTopLeft = r < 7 && c < 7;
      const inTopRight = r < 7 && c >= modules - 7;
      const inBottomLeft = r >= modules - 7 && c < 7;
      if (!inTopLeft && !inTopRight && !inBottomLeft) {
        const bit = ((hashVal ^ (r * 31 + c * 17)) >>> ((r + c) % 16)) & 1;
        if (bit === 1) {
          doc.rect(x + c * cellSize, y + r * cellSize, cellSize, cellSize, 'F');
        }
      }
    }
  }
}

export function downloadPdfRetentionVoucher(agentName: string, agentRif: string, inv: FiscalInvoice) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const ym = inv.emissionDate.replace(/-/g, '').slice(0, 6);
  const seq = parseInt(inv.id.replace(/\D/g, '') || '1', 10);
  const voucher14 = buildVoucher14Digits(ym, seq);

  const baseBs = toVes(inv.taxableBaseOriginal, inv.currency, inv.bcvRateOnDate);
  const vatBs = toVes(inv.vatOriginal, inv.currency, inv.bcvRateOnDate);
  const totalBs = toVes(inv.totalOriginal, inv.currency, inv.bcvRateOnDate);
  const withheldBs = vatBs * (inv.vatRetentionRate / 100);

  doc.setDrawColor(203, 213, 225);
  doc.setLineWidth(0.4);
  doc.rect(10, 10, 190, 277);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text('REPÚBLICA BOLIVARIANA DE VENEZUELA', 105, 18, { align: 'center' });
  doc.setFontSize(10);
  doc.text('SERVICIO NACIONAL INTEGRADO DE ADMINISTRACIÓN ADUANERA Y TRIBUTARIA (SENIAT)', 105, 23, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text('Providencia Administrativa SNAT/2026/00093 · Art. 18 (Gaceta Oficial Nº 43.484)', 105, 27.5, { align: 'center' });

  doc.setFillColor(248, 250, 252);
  doc.rect(14, 32, 182, 18, 'F');
  doc.setDrawColor(226, 232, 240);
  doc.rect(14, 32, 182, 18);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(15, 23, 42);
  doc.text('COMPROBANTE DE RETENCIÓN DEL I.V.A.', 18, 41);
  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.text(`Período Fiscal: ${inv.emissionDate.slice(0, 7)} · Fecha de Emisión: ${inv.emissionDate}`, 18, 46);

  doc.setFont('courier', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(180, 83, 9);
  doc.text(`Nº ${voucher14}`, 192, 43, { align: 'right' });

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  doc.text('1. DATOS DEL AGENTE DE RETENCIÓN (COMPRADOR):', 14, 57);
  doc.setFont('helvetica', 'normal');
  doc.text(`Nombre / Razón Social: ${agentName}`, 14, 62);
  doc.text(`Registro de Información Fiscal (RIF): ${agentRif}`, 14, 66.5);

  doc.setFont('helvetica', 'bold');
  doc.text('2. DATOS DEL SUJETO RETENIDO (PROVEEDOR):', 14, 74);
  doc.setFont('helvetica', 'normal');
  doc.text(`Nombre / Razón Social: ${inv.supplierName}`, 14, 79);
  doc.text(`Registro de Información Fiscal (RIF): ${inv.supplierRif}`, 14, 83.5);

  doc.setFillColor(241, 245, 249);
  doc.rect(14, 91, 182, 8, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(15, 23, 42);
  doc.text('Fecha', 16, 96);
  doc.text('Nº Factura', 35, 96);
  doc.text('Nº Control', 57, 96);
  doc.text('Total Compra', 83, 96);
  doc.text('Base Imponible', 108, 96);
  doc.text('% Alic.', 133, 96);
  doc.text('Impuesto IVA', 147, 96);
  doc.text('% Ret.', 170, 96);
  doc.text('IVA Retenido', 183, 96);

  doc.setFont('courier', 'normal');
  doc.setFontSize(8);
  doc.text(inv.emissionDate, 16, 105);
  doc.text(inv.invoiceNumber, 35, 105);
  doc.text(inv.controlNumber, 57, 105);
  doc.text(`Bs. ${totalBs.toFixed(2)}`, 83, 105);
  doc.text(`Bs. ${baseBs.toFixed(2)}`, 108, 105);
  doc.text(`${inv.vatRate}%`, 133, 105);
  doc.text(`Bs. ${vatBs.toFixed(2)}`, 147, 105);
  doc.text(`${inv.vatRetentionRate}%`, 170, 105);
  doc.setFont('courier', 'bold');
  doc.setTextColor(180, 83, 9);
  doc.text(`Bs. ${withheldBs.toFixed(2)}`, 183, 105);

  doc.setDrawColor(203, 213, 225);
  doc.line(14, 112, 196, 112);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  doc.text('TOTAL IMPUESTO RETENIDO:', 130, 119);
  doc.setFont('courier', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(16, 185, 129);
  doc.text(`Bs. ${withheldBs.toLocaleString('es-VE', { minimumFractionDigits: 2 })}`, 196, 119, { align: 'right' });

  doc.setFillColor(248, 250, 252);
  doc.rect(14, 128, 182, 36, 'F');
  doc.setDrawColor(226, 232, 240);
  doc.rect(14, 128, 182, 36);

  drawVectorQr(doc, 18, 131, 30, inv.auditHash || voucher14);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  doc.text('VALIDACIÓN Y SELLO CRIPTOGRÁFICO INMUTABLE:', 53, 136);
  doc.setFont('courier', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`Hash SHA-256: ${inv.auditHash || 'GENESIS_SENIAT_2026'}`, 53, 142);
  doc.text(`Algoritmo: AES-256-GCM + SHA-256 Chained Integrity Vault`, 53, 147);
  doc.text(`Custodia Legal: Código Orgánico Tributario (COT Art. 10 años)`, 53, 152);
  doc.text(`Verificación Móvil: Escanee el código QR para validar emisión fiscal oficial`, 53, 157);

  const sigY = 210;
  doc.setDrawColor(71, 85, 105);
  doc.setLineWidth(0.3);
  doc.line(25, sigY, 90, sigY);
  doc.line(120, sigY, 185, sigY);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  doc.text('Agente de Retención (Firma y Sello)', 57.5, sigY + 5, { align: 'center' });
  doc.text(agentName, 57.5, sigY + 9, { align: 'center' });

  doc.text('Sujeto Retenido / Proveedor', 152.5, sigY + 5, { align: 'center' });
  doc.text(inv.supplierName, 152.5, sigY + 9, { align: 'center' });

  doc.setFontSize(7.5);
  doc.setTextColor(148, 163, 184);
  doc.text('Documento generado por VeneTurco Fiscal OS v3.1 · Sistema Homologado Providencia SNAT/2026/00093', 105, 282, { align: 'center' });

  doc.save(`Comprobante_Retencion_IVA_${voucher14}.pdf`);
}

export function downloadPdfPaystub(companyName: string, companyRif: string, emp: PayrollEmployee) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const b = calculateLotttFullBreakdown(emp.baseSalaryBs, emp.cestaticketBs, emp.riskLevel);

  doc.setDrawColor(203, 213, 225);
  doc.rect(10, 10, 190, 277);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(15, 23, 42);
  doc.text(companyName.toUpperCase(), 105, 20, { align: 'center' });
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.text(`RIF: ${companyRif} · RECIBO DE PAGO DE NÓMINA (LOTTT)`, 105, 25, { align: 'center' });

  doc.setFillColor(248, 250, 252);
  doc.rect(14, 32, 182, 22, 'F');
  doc.setDrawColor(226, 232, 240);
  doc.rect(14, 32, 182, 22);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  doc.text(`Trabajador: ${emp.fullName}`, 18, 40);
  doc.text(`Cédula de Identidad: ${emp.cedula}`, 18, 46);
  doc.text(`Cargo / Posición: ${emp.role}`, 115, 40);
  doc.text(`Fecha Ingreso: ${emp.hireDate} · Riesgo IVSS: ${emp.riskLevel}`, 115, 46);

  doc.setFillColor(241, 245, 249);
  doc.rect(14, 60, 182, 8, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text('Concepto / Descripción Legal', 18, 65.5);
  doc.text('Asignaciones Bs.', 130, 65.5);
  doc.text('Deducciones Bs.', 165, 65.5);

  let curY = 75;
  function addRow(concept: string, asig: number, ded: number) {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(30, 41, 59);
    doc.text(concept, 18, curY);
    doc.setFont('courier', 'normal');
    doc.text(asig > 0 ? `Bs. ${asig.toFixed(2)}` : '0.00', 130, curY);
    doc.text(ded > 0 ? `Bs. ${ded.toFixed(2)}` : '0.00', 165, curY);
    curY += 7;
  }

  addRow('Salario Base Mensual Ordinario', emp.baseSalaryBs, 0);
  addRow('Cestaticket Socialista de Alimentación (Decreto Presidencial)', emp.cestaticketBs, 0);
  addRow('Retención Seguro Social Obligatorio IVSS (4%)', 0, b.ivssEmployee);
  addRow('Retención Régimen Prestacional de Vivienda FAOV (1%)', 0, b.faovEmployee);
  addRow('Retención Régimen Prestacional de Empleo RPE (0.5%)', 0, b.rpeEmployee);

  doc.setDrawColor(203, 213, 225);
  doc.line(14, curY + 2, 196, curY + 2);
  curY += 10;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text('TOTAL NETO A PAGAR AL TRABAJADOR:', 75, curY);
  doc.setFont('courier', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(16, 185, 129);
  doc.text(`Bs. ${b.netPayBs.toLocaleString('es-VE', { minimumFractionDigits: 2 })}`, 196, curY, { align: 'right' });

  curY += 14;
  doc.setFillColor(248, 250, 252);
  doc.rect(14, curY, 182, 18, 'F');
  doc.setDrawColor(226, 232, 240);
  doc.rect(14, curY, 182, 18);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(180, 83, 9);
  doc.text('GARANTÍA DE PRESTACIONES SOCIALES (ART. 142 LOTTT):', 18, curY + 6);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.text(`Provisión Mensual Acumulada: Bs. ${b.prestacionesMonthlyProvision.toFixed(2)} depositados en fideicomiso o contabilidad.`, 18, curY + 12);

  drawVectorQr(doc, 18, curY + 25, 26, `LOTTT_${emp.cedula}_${b.netPayBs}`);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(71, 85, 105);
  doc.text('Comprobante digital inmutable sellado por VeneTurco Fiscal OS', 48, curY + 34);
  doc.text('Cumplimiento estricto Ley Orgánica del Trabajo, los Trabajadores y las Trabajadoras', 48, curY + 39);

  const sigY = 225;
  doc.setDrawColor(71, 85, 105);
  doc.line(25, sigY, 90, sigY);
  doc.line(120, sigY, 185, sigY);

  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  doc.text('Por la Empresa (Representante Legal)', 57.5, sigY + 5, { align: 'center' });
  doc.text('Recibí Conforme (Firma del Trabajador)', 152.5, sigY + 5, { align: 'center' });

  doc.save(`Recibo_Nomina_${emp.cedula.replace(/\D/g, '')}.pdf`);
}



